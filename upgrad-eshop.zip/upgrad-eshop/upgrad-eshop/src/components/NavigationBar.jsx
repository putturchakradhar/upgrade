import React from "react";
import { AppBar, Toolbar, Typography, Button, TextField } from "@mui/material";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { Link, useNavigate } from "react-router-dom";

const NavigationBar = ({ isLoggedIn, isAdmin, handleLogout }) => {
  const navigate = useNavigate();

  const handleSearch = (event) => {
    if (event.key === "Enter") {
      const query = event.target.value;
      navigate(`/search?q=${query}`);
    }
  };

  return (
    <AppBar position="static" color="primary">
      <Toolbar>
        {/* Logo */}
        <ShoppingCartIcon fontSize="large" />
        <Typography variant="h6" style={{ flexGrow: 1, marginLeft: 10 }}>
          upGrad Eshop
        </Typography>

        {/* Not Logged In */}
        {!isLoggedIn && (
          <>
            <Button color="inherit" component={Link} to="/login">
              Login
            </Button>
            <Button color="inherit" component={Link} to="/signup">
              Signup
            </Button>
          </>
        )}

        {/* Logged In */}
        {isLoggedIn && (
          <>
            <TextField
              variant="outlined"
              size="small"
              placeholder="Search..."
              style={{ backgroundColor: "#fff", borderRadius: 5 }}
              onKeyDown={handleSearch}
            />
            <Button color="inherit" component={Link} to="/">
              Home
            </Button>
            <Button color="inherit" onClick={handleLogout}>
              Logout
            </Button>
          </>
        )}

        {/* Admin Feature */}
        {isAdmin && (
          <Button color="inherit" component={Link} to="/add-product">
            Add Product
          </Button>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default NavigationBar;
