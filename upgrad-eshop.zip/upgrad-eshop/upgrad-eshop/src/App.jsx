import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NavigationBar from "./components/NavigationBar";
import LoginPage from "./components/LoginPage";
import SignupPage from "./components/SignupPage";
import ProductsPage from "./components/ProductsPage";
import ProductDetails from "./components/ProductDetails";

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const handleLogin = (role) => {
    setIsLoggedIn(true);
    if (role === "admin") setIsAdmin(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdmin(false);
  };

  return (
    <Router>
      <NavigationBar
        isLoggedIn={isLoggedIn}
        isAdmin={isAdmin}
        handleLogout={handleLogout}
      />
      <Routes>
      <Route path="/" element={<ProductsPage products={products} isAdmin={true} />} />
      <Route path="/add-product" element={<AddProduct />} />
       <Route path="/edit-product/:id" element={<EditProduct />} />
       <Route path="/" element={<ProductsPage />} />
       <Route path="/product/:id" element={<ProductDetails />} />
       <Route path="/products" element={<ProductsPage isLoggedIn={isLoggedIn} isAdmin={isAdmin} />} />
        <Route path="/login" element={<LoginPage onLogin={handleLogin} />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/" element={<h1>Home Page</h1>} />
        <Route path="/add-product" element={<h1>Add Product Page</h1>} />
        <Route path="/search" element={<h1>Search Results</h1>} />
      </Routes>
    </Router>
  );
};

export default App;
