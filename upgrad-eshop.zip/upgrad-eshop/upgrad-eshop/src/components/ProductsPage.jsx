import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  ToggleButtonGroup,
  ToggleButton,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import axios from "axios";
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";

const ProductsPage = ({ isLoggedIn, isAdmin }) => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortOption, setSortOption] = useState("default");
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoggedIn) {
      navigate("/login");
      return;
    }

    // Fetch products and categories
    axios.get("/products").then((res) => setProducts(res.data));
    axios.get("/products/categories").then((res) => setCategories(res.data));
  }, [isLoggedIn, navigate]);

  // Filter and sort products based on category and sort option
  useEffect(() => {
    let filtered = products;

    if (selectedCategory !== "all") {
      filtered = filtered.filter((p) => p.category === selectedCategory);
    }

    switch (sortOption) {
      case "priceHighToLow":
        filtered = [...filtered].sort((a, b) => b.price - a.price);
        break;
      case "priceLowToHigh":
        filtered = [...filtered].sort((a, b) => a.price - b.price);
        break;
      case "newest":
        filtered = [...filtered].sort(
          (a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)
        );
        break;
      default:
        break; // Default is the original order
    }

    setFilteredProducts(filtered);
  }, [products, selectedCategory, sortOption]);

  const handleDelete = (product) => {
    setSelectedProduct(product);
    setOpenDialog(true);
  };

  const confirmDelete = () => {
    if (selectedProduct) {
      // Delete product API call
      axios
        .delete(`/products/${selectedProduct.id}`)
        .then(() => {
          alert(`Product ${selectedProduct.name} deleted successfully`);
          setProducts(products.filter((p) => p.id !== selectedProduct.id));
        })
        .catch((error) => {
          console.error("Error deleting product:", error);
        });
    }
    setOpenDialog(false);
  };

  return (
    <div style={{ padding: "20px" }}>
      {/* Category Toggle */}
      <ToggleButtonGroup
        value={selectedCategory}
        exclusive
        onChange={(e, value) => setSelectedCategory(value || "all")}
        style={{ marginBottom: "20px" }}
      >
        <ToggleButton value="all">All</ToggleButton>
        {categories.map((category) => (
          <ToggleButton key={category} value={category}>
            {category}
          </ToggleButton>
        ))}
      </ToggleButtonGroup>

      {/* Sort Dropdown */}
      <FormControl style={{ marginLeft: "20px", minWidth: 150 }}>
        <InputLabel>Sort By</InputLabel>
        <Select value={sortOption} onChange={(e) => setSortOption(e.target.value)}>
          <MenuItem value="default">Default</MenuItem>
          <MenuItem value="priceHighToLow">Price: High to Low</MenuItem>
          <MenuItem value="priceLowToHigh">Price: Low to High</MenuItem>
          <MenuItem value="newest">Newest</MenuItem>
        </Select>
      </FormControl>

      {/* Products Grid */}
      <Grid container spacing={3} style={{ marginTop: "20px" }}>
        {filteredProducts.map((product) => (
          <Grid item xs={12} sm={6} md={4} key={product.id}>
            <Card>
              <CardMedia
                component="img"
                height="140"
                image={product.imageUrl}
                alt={product.name}
              />
              <CardContent>
                <Typography variant="h6">{product.name}</Typography>
                <Typography color="textSecondary">${product.price}</Typography>
                {isAdmin && (
                  <>
                    <Button
                      variant="contained"
                      color="primary"
                      style={{ marginTop: "10px" }}
                      onClick={() => navigate(`/edit-product/${product.id}`)}
                    >
                      <EditIcon />
                      Edit
                    </Button>
                    <Button
                      variant="contained"
                      color="secondary"
                      style={{ marginTop: "10px" }}
                      onClick={() => handleDelete(product)}
                    >
                      <DeleteIcon />
                      Delete
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Delete Confirmation Dialog */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          Are you sure you want to delete the product{" "}
          <strong>{selectedProduct?.name}</strong>?
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)} color="default">
            Cancel
          </Button>
          <Button onClick={confirmDelete} color="secondary">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default ProductsPage;
