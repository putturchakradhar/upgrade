import React from "react";
import { AppBar, Toolbar, Typography, Button } from "@material-ui/core";
import { useNavigate } from "react-router-dom";

const AdminAppBar = () => {
  const navigate = useNavigate();

  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" style={{ flexGrow: 1 }}>
          Product Management
        </Typography>
        <Button color="inherit" onClick={() => navigate("/add-product")}>
          Add Product
        </Button>
      </Toolbar>
    </AppBar>
  );
};

export default AdminAppBar;
