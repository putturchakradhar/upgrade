import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { Button, TextField, Card, CardContent, Typography } from "@material-ui/core";

const ProductDetails = () => {
  const { id } = useParams(); // Retrieve product ID from the route
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch product details
    axios
      .get(`/products/${id}`)
      .then((response) => {
        setProduct(response.data);
      })
      .catch((error) => {
        console.error("Error fetching product details:", error);
        navigate("/"); // Redirect if product not found
      });
  }, [id, navigate]);

  if (!product) {
    return <Typography variant="h5">Loading product details...</Typography>;
  }

  const handleQuantityChange = (event) => {
    setQuantity(event.target.value);
  };

  const handleBuyNow = () => {
    alert(`Buying ${quantity} of ${product.name}`);
    // Additional logic to process the order can go here
  };

  return (
    <Card>
      <CardContent>
        <Typography variant="h4">{product.name}</Typography>
        {product.imageUrl ? (
          <img src={product.imageUrl} alt={product.name} style={{ width: "100%", maxWidth: "300px" }} />
        ) : (
          <Typography variant="subtitle1">Image not available</Typography>
        )}
        <Typography variant="h6">Price: ${product.price}</Typography>
        <Typography variant="body1">Category: {product.category}</Typography>
        <TextField
          label="Quantity"
          type="number"
          value={quantity}
          onChange={handleQuantityChange}
          inputProps={{ min: 1 }}
          style={{ marginTop: "20px", marginBottom: "20px" }}
        />
        <Button variant="contained" color="primary" onClick={handleBuyNow}>
          Buy Now
        </Button>
      </CardContent>
    </Card>
  );
};

export default ProductDetails;
