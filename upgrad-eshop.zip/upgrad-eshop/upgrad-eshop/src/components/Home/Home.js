import NavigationBar from "./components/NavigationBar";  // Adjusted path

function Home(){
    return (
        <div>
            <NavigationBar/>
            </div>
    );
}

export default Home;