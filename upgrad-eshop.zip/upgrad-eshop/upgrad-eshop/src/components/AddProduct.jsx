import React, { useState } from "react";
import { TextField, Button, Card, CardContent } from "@material-ui/core";
import axios from "axios";

const AddProduct = () => {
  const [product, setProduct] = useState({ name: "", price: "", category: "", imageUrl: "" });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setProduct((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    axios.post("/products", product).then(() => {
      alert("Product added successfully");
    });
  };

  return (
    <Card>
      <CardContent>
        <TextField name="name" label="Name" value={product.name} onChange={handleChange} fullWidth />
        <TextField name="price" label="Price" value={product.price} onChange={handleChange} fullWidth />
        <TextField name="category" label="Category" value={product.category} onChange={handleChange} fullWidth />
        <TextField name="imageUrl" label="Image URL" value={product.imageUrl} onChange={handleChange} fullWidth />
        <Button onClick={handleSubmit} variant="contained" color="primary">
          Add Product
        </Button>
      </CardContent>
    </Card>
  );
};

export default AddProduct;
